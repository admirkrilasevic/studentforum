package interact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.html5.LocalStorage;
import org.openqa.selenium.html5.WebStorage;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class InteractionTest {
	static WebDriver webDriver;
	static String baseUrl;
	
	@BeforeAll
	static void setUp() {
		System.setProperty("webdriver.chrome.driver", "/home/vedranselak/Documents/google-driver2/chromedriver");
		webDriver = new ChromeDriver();
		baseUrl = "https://askibu.herokuapp.com";
	}
	
	@AfterAll
	static void tearDown() {
		webDriver.close();
	}
	
	
	@Order(1)
	@Test
	void testAskQuestionLoggedOut() throws InterruptedException {
		webDriver.get(baseUrl + "/home");
		webDriver.manage().window().maximize();
		LocalStorage localS = ((WebStorage) webDriver).getLocalStorage();
		localS.clear();
		Thread.sleep(2000);
		WebElement faculty = webDriver.findElement(By.id("faculty-1"));
		faculty.click();
		Thread.sleep(100);
		WebElement department = webDriver.findElement(By.id("department-1"));
		department.click();
		Thread.sleep(500);
		WebElement course = webDriver.findElement(By.id("course-1"));
		course.click();
		Thread.sleep(500);
		assertEquals(baseUrl + "/home/1/1", webDriver.getCurrentUrl());
		Thread.sleep(500);
		WebElement askQuestionButton = webDriver.findElement(By.id("add-question"));
		askQuestionButton.click();
		Thread.sleep(2000);
		WebElement alert = webDriver.findElement(By.xpath("//*[@class='Toastify__toast-body']/div[2]"));
				
		assertEquals(alert.getText(), "You must be logged in to add a question");
		Thread.sleep(2000);
	}

	@Order(2)
	@Test
	void testAskQuestion() throws InterruptedException {
		webDriver.get(baseUrl + "/login");
		webDriver.manage().window().maximize();
		Thread.sleep(1000);
		WebElement emailInput = webDriver.findElement(By.id("email"));
		WebElement passwordInput = webDriver.findElement(By.id("password"));
		Thread.sleep(1000);
		emailInput.sendKeys("svvt.project@gmail.com");
		Thread.sleep(1000);
		passwordInput.sendKeys("password123");
		WebElement loginButton = webDriver.findElement(By.id("submit-button"));
		loginButton.click();
		Thread.sleep(1000);
		assertEquals(baseUrl + "/home", webDriver.getCurrentUrl());
		webDriver.get(baseUrl + "/home/1/1");
		Thread.sleep(500);
		WebElement askQuestionButton = webDriver.findElement(By.id("add-question"));
		askQuestionButton.click();
		Thread.sleep(500);
		WebElement subject = webDriver.findElement(By.id("question-subject"));
		WebElement body = webDriver.findElement(By.id("question-body"));
		subject.sendKeys("Some subject");
		body.sendKeys("Some body here");
		Thread.sleep(1000);
		WebElement submitQuestionButton = webDriver.findElement(By.id("add-question-submit"));
		submitQuestionButton.click();
		Thread.sleep(1000);
		WebElement questionSubject = webDriver.findElement(By.className("questionSubject"));
		WebElement questionBody = webDriver.findElement(By.className("questionBody"));
		assertEquals(questionSubject.getText(), "Some subject");
		assertEquals(questionBody.getText(), "Some body here");
		Thread.sleep(1000);
	}

	@Order(3)
	@Test
	void testAddAnswerLoggedOut() throws InterruptedException {
		webDriver.get(baseUrl + "/home/1/1");
		webDriver.manage().window().maximize();
		LocalStorage localS = ((WebStorage) webDriver).getLocalStorage();
		localS.clear();
		Thread.sleep(2000);
		WebElement viewAnswers = webDriver.findElement(By.className("viewAnswers"));
		viewAnswers.click();
		Thread.sleep(500);
		WebElement addAnswerButton = webDriver.findElement(By.className("addAnswer"));
		assertNotNull(addAnswerButton);
		addAnswerButton.click();
		Thread.sleep(2000);
		WebElement alert = webDriver.findElement(By.xpath("//*[@class='Toastify__toast-body']/div[2]"));
		assertEquals(alert.getText(), "You must be logged in to add an answer");
		Thread.sleep(1500);
	}

	@Order(4)
	@Test
	void testAddAnswer() throws InterruptedException {
		webDriver.get(baseUrl + "/login");
		webDriver.manage().window().maximize();
		Thread.sleep(1000);
		WebElement emailInput = webDriver.findElement(By.id("email"));
		WebElement passwordInput = webDriver.findElement(By.id("password"));
		Thread.sleep(1000);
		emailInput.sendKeys("svvt.project@gmail.com");
		Thread.sleep(1000);
		passwordInput.sendKeys("password123");
		WebElement loginButton = webDriver.findElement(By.id("submit-button"));
		loginButton.click();
		Thread.sleep(1000);
		assertEquals(baseUrl + "/home", webDriver.getCurrentUrl());
		webDriver.get(baseUrl + "/home/1/1");
		Thread.sleep(500);
		WebElement viewAnswers = webDriver.findElement(By.className("viewAnswers"));
		viewAnswers.click();
		Thread.sleep(1000);
		WebElement addAnswerButton = webDriver.findElement(By.className("addAnswer"));
		addAnswerButton.click();
		Thread.sleep(500);
		WebElement body = webDriver.findElement(By.className("answerBody"));
		body.sendKeys("Some answer body here");
		Thread.sleep(1000);
		WebElement saveAnswerButton = webDriver.findElement(By.className("saveAnswer"));
		saveAnswerButton.click();
		Thread.sleep(500);
		assertNotNull(webDriver.findElement(By.xpath("//*[text()='Some answer body here']")));
		Thread.sleep(1000);
	}

	@Order(5)
	@Test
	void testPinAnswer() throws InterruptedException {
		WebElement pinIcon = webDriver.findElement(By.className("pinAnswer"));
		pinIcon.click();
		Thread.sleep(1000);
		assertNotNull(webDriver.findElement(By.className("pinnedAnswer")));
		Thread.sleep(1000);
	}

}
