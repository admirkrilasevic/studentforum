package account;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.html5.LocalStorage;
import org.openqa.selenium.html5.WebStorage;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class LoginTest {
	static WebDriver webDriver;
	static String baseUrl;
	
	@BeforeAll
	static void setUp() {
		System.setProperty("webdriver.chrome.driver", "/home/vedranselak/Documents/google-driver2/chromedriver");
		webDriver = new ChromeDriver();
		baseUrl = "https://askibu.herokuapp.com";
	}
	
	@AfterAll
	static void tearDown() {
		webDriver.close();
	}


	@Order(1)
	@Test
	void loginInvalidInputTest() throws InterruptedException {
		webDriver.get(baseUrl + "/login");
		webDriver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement emailInput = webDriver.findElement(By.id("email"));
		WebElement passwordInput = webDriver.findElement(By.id("password"));
		emailInput.sendKeys("svvt.project@gmail.com");
		passwordInput.sendKeys("invalidPassword");
		WebElement loginButton = webDriver.findElement(By.id("submit-button"));
		loginButton.click();
		Thread.sleep(1000);
		WebElement loginStatus = webDriver.findElement(By.id("error-message"));
		assertEquals("Invalid password", loginStatus.getText());
		Thread.sleep(1000);
	}

	@Order(2)
	@Test
	void loginValidInputTest() throws InterruptedException {
		webDriver.get(baseUrl + "/login");
		webDriver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement emailInput = webDriver.findElement(By.id("email"));
		WebElement passwordInput = webDriver.findElement(By.id("password"));
		Thread.sleep(1000);
		emailInput.sendKeys("svvt.project@gmail.com");
		Thread.sleep(1000);
		passwordInput.sendKeys("password123");
		WebElement loginButton = webDriver.findElement(By.id("submit-button"));
		Thread.sleep(1000);
		loginButton.click();
		Thread.sleep(1000);
		assertEquals(baseUrl + "/home", webDriver.getCurrentUrl());
		LocalStorage localS = ((WebStorage) webDriver).getLocalStorage();
		assertTrue(localS.getItem("user").contains("token"));
		Thread.sleep(1000);
	}
	
	@Order(3)
	@Test
	void logoutTest() throws InterruptedException {
		webDriver.get(baseUrl + "/home");
		webDriver.manage().window().maximize();
		Thread.sleep(1000);
		WebElement logoutLink = webDriver.findElement(By.id("logout-link"));
		logoutLink.click();
		Thread.sleep(500);
		assertEquals(baseUrl + "/account/profile", webDriver.getCurrentUrl());
		WebElement logoutButton = webDriver.findElement(By.id("logout-button"));
		logoutButton.click();
		Thread.sleep(500);
		assertEquals(baseUrl + "/home", webDriver.getCurrentUrl());
		LocalStorage localS = ((WebStorage) webDriver).getLocalStorage();
		assertNull(localS.getItem("user"));
		Thread.sleep(1000);
	}
}
